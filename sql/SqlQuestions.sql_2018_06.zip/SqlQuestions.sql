

-- SQL的话给了employee, department等四个表，但是问到的两个问题只用到了employee和department两个表。
-- Employee表有employee_id, first_name, second_name, salary, department_id五个fields，
-- department表有id, department_name两个fields。

-- SQL一：Find all department_name which the total salary of this department is larger than 40000.
SELECT d.Department_name
FROM Employee e JOIN Department d
ON e.Department_id = d.Department_id
GROUP BY d.Department_name
HAVING SUM(e.Salary) > 40000

-- SQL二：Find the employee in each department who has the max salary and print their names and salaries.
SELECT d.Name AS Department, e.Name AS Employee, e.Salay
FROM Department d JOIN Employee e
ON d.Department_id = e.Department_id AND e.Salary = (
  SELECT MAX(Salary)
  FROM Employee e2
  WHERE e2.Department_id = d.Department_id)


SELECT CONCAT(e.first_name,'', e.second_name) AS name, e.salary
FROM employee e JOIN department d
ON e.department_id = d.department_id
WHERE e.salary, d.department_id IN
( SELECT MAX(e.salary),  d.department_id
  FROM employee e JOIN department d
  ON e. Department_id = d.department_id
  GROUP BY d.department_id)

-- 问题一: Find the percentage of the customer who at least puchase 1 product.
SELECT COUNT(DISTINCT Sales.CustomerId) / COUNT(DISTINCT Customer.CustomerId)
FROM Sales, Customer

-- 问题二: Find (2015 total sales revenue / 2014 total sales revenue) - 1 for all the stores..

SELECT StoreId, SUM(IF(YEAR(Sales_date) = '2015', revenue, 0)) / SUM(IF(YEAR(Sales_date) = '2014', revenue, 0)) - 1
FROM Sales
GROUP BY StoreId

-- tables:
-- customers: id, name, birthday, gender
-- stores: id, state, area_squarefeet
-- product: id, name,....
-- sale: product_id, store_id, customer_id ...


-- 1. Percentage of male in customers
SELECT SUM(CASE WHEN gender = 'male' THEN 1 ELSE 0 END) / COUNT(*)
FROM Customer

-- 2. Percentage of customers who has at least 1 product
SELECT SUM(CASE WHEN product_id IS NULL THEN 0 ELSE 1 END) / COUNT(*) as ratio
FROM(
      SELECT c.name, product_id
      FROM customers c LEFT JOIN sale s
      ON c.id = s.customer_id
      GROUP BY c.id
    ) temp ;

-- 3. how many distinct states are all the store located -- count(distinct state)
SELECT COUNT(DISTINCT(state))
FROM stores

-- 3. count the product having at least 5 unit orders
SELECT COUNT (*)
    FROM
    ( SELECT product_id
      FROM sale
      GROUP BY product_id
      HAVING SUM(unit_order) >= 5) temp

-- 4. how many stores are having more than 26000 area sqrt, count by state basis
SELECT state, COUNT(id)
FROM stores s
WHERE area_squarefeet > 26000
GROUP BY state
-- 5. print out the oldest and youngest customer's birthday on gender level
SELECT gender, MIN(birthday), MAX(birthday)
FROM customers
GROUP BY gender

-- sql part： 4 or 5 questions. given 4 tables 产品，销售，客户, etc. cannot remember all the questions
-- * 找到最多的first name是什么

SELECT c.First_name
FROM Customer c
GROUP BY c.First_name
ORDER BY COUNT(*) DESC
LIMIT 1

-- * 找到前三销量的产品类别是什么
SELECT o.name,  AS Cnt
FROM Orders o
GROUP BY o.product_name
ORDER BY COUNT(*) DESC
LIMIT 3

-- * 购买了某两种产品的客户id是什么


